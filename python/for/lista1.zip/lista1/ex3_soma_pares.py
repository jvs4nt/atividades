# Escreva um programa que calcule a soma de todos os números pares entre 1 e 20.

print(" ")

soma = 0

for i in range(0, 21, 2):
    soma += i

print (f"Soma total = {soma}")    

print(" ")