package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Empresa;
import br.com.fiap.beans.Endereco;
import br.com.fiap.beans.Produto;

public class TesteSistema {

	public static void main(String[] args) {
		
		//String razaoSocial, String email, int unidade
		Empresa objEmpresa = new Empresa(
				JOptionPane.showInputDialog("Razao social: "),
				JOptionPane.showInputDialog("Email: "),
				Integer.parseInt(JOptionPane.showInputDialog("Unidades: "))
				);
		
		//String logradouro, String cep, String bairro, int numero
		Endereco objEndereco = new Endereco(
				JOptionPane.showInputDialog("Logradouro: "),
				JOptionPane.showInputDialog("CEP: "),
				JOptionPane.showInputDialog("Bairro: "),
				Integer.parseInt(JOptionPane.showInputDialog("Numero: "))
				);
		objEmpresa.setEndereco(objEndereco);
		
		//int codigo, String tipo, String marca, double valor
		Produto objProduto = new Produto(
				Integer.parseInt(JOptionPane.showInputDialog("Codigo: ")),
				JOptionPane.showInputDialog("Tipo: "),
				JOptionPane.showInputDialog("Marca: "),
				Double.parseDouble(JOptionPane.showInputDialog("Valor: "))
				);
		
		//Saida
		System.out.println("EMPRESA: " + objEmpresa.getRazaoSocial() +
				"\nEmail: "+ objEmpresa.getEmail() +
				"\nUnidades: " + objEmpresa.getUnidade() +
				"\nLogradouro: " + objEndereco.getLogradouro() +
				"\nCEP: " + objEndereco.getCep() +
				"\nBairro: " + objEndereco.getBairro() +
				"\nNumero: " + objEndereco.getNumero() + 
				"\n\nPRODUTO: " +
				"\nCodigo: " + objProduto.getCodigo() +
				"\nTipo: " + objProduto.getTipo() +
				"\nMarca: " + objProduto.getMarca() +
				"\nValor: " + objProduto.getValor());

	}

}
