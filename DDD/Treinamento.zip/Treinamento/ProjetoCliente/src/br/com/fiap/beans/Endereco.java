package br.com.fiap.beans;

public class Endereco {
	
	// Visibilidade , tipos e variaveis
	
	private String logradouro;
	private int numero;
	private String complemento;
	private String cep;
	
	// Setters (Entrada) e Getters (Exibir)
	
	public String getLogradouro() {
		return logradouro;
	}
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}

}
